--
-- Please see the license.html file included with this distribution for
-- attribution and copyright information.
--

function onInit()
	self.updateDisplay();
end

function onCasterTypeChanged()
	self.updateDisplay();
end

function updateDisplay()
	local sCasterType = castertype.getValue();
	local bSpells = (sCasterType == "memorization");

	groupuses_label.setVisible(not bSpells);
	uses.setVisible(not bSpells);
	usesperiod.setVisible(not bSpells);

	groupprepared_label.setVisible(bSpells);
	prepared.setVisible(bSpells);
end
